const FLOW_HOME = "https://labs.google/fx/tools/flow";
const CINEGEN_API = "http://127.0.0.1:3002/api/cinegen/flow";

async function flowTabs() {
  return chrome.tabs.query({ url: ["https://labs.google/fx/*", "https://labs.google/flow/*"] });
}

async function notifyFlowAgent(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "CINEGEN_FLOW_PROCESS_QUEUE" });
  } catch {
    // The content script will read the queue when the Flow page finishes loading.
  }
}

async function api(path, options = {}) {
  const response = await fetch(`${CINEGEN_API}${path}`, {
    cache: "no-store",
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload?.error || `HTTP ${response.status}`);
  return payload;
}

async function inspectFlowTab() {
  const tabs = await flowTabs();
  const tab = tabs.find((item) => item.url?.includes("/project/")) || tabs[0];
  let pageStatus = {};
  if (tab?.id) {
    try {
      pageStatus = await chrome.tabs.sendMessage(tab.id, { type: "CINEGEN_FLOW_PAGE_STATUS" });
    } catch {
      pageStatus = {};
    }
  }
  return {
    tab,
    status: {
      connected: Boolean(tab && pageStatus?.signedIn),
      plan: pageStatus?.plan,
      tabUrl: tab?.url,
      extensionVersion: chrome.runtime.getManifest().version,
    },
  };
}

async function syncWithCineGen() {
  try {
    const { tab, status } = await inspectFlowTab();
    await api("/heartbeat", {
      method: "POST",
      body: JSON.stringify(status),
    });

    const command = await api("/open");
    if (command?.openFlow) {
      if (tab?.id) await chrome.tabs.update(tab.id, { active: true });
      else await chrome.tabs.create({ url: FLOW_HOME, active: true });
    }

    const { activeFlowJobId } = await chrome.storage.local.get("activeFlowJobId");
    if (!activeFlowJobId) {
      const next = await api("/jobs/next");
      if (next?.job?.id) {
        const job = next.job;
        await chrome.storage.local.set({
          [`job:${job.id}`]: job,
          activeFlowJobId: job.id,
        });
        let target = tab;
        if (!target?.id) target = await chrome.tabs.create({ url: FLOW_HOME, active: false });
        if (target.id) await notifyFlowAgent(target.id);
      }
    }
  } catch {
    // O CineGen pode estar fechado; o próximo ciclo tenta novamente.
  }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("cinegen-flow-sync", { periodInMinutes: 0.5 });
  syncWithCineGen();
});
chrome.runtime.onStartup.addListener(syncWithCineGen);
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "cinegen-flow-sync") syncWithCineGen();
});
setInterval(syncWithCineGen, 5000);
syncWithCineGen();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    if (message.type === "CINEGEN_FLOW_STATUS") {
      const { status } = await inspectFlowTab();
      sendResponse({
        ok: true,
        payload: status,
      });
      return;
    }

    if (message.type === "CINEGEN_FLOW_OPEN") {
      const tabs = await flowTabs();
      if (tabs[0]?.id) {
        await chrome.tabs.update(tabs[0].id, { active: true });
      } else {
        await chrome.tabs.create({ url: FLOW_HOME, active: true });
      }
      sendResponse({ ok: true, payload: { opened: true } });
      return;
    }

    if (message.type === "CINEGEN_FLOW_GENERATE") {
      const jobId = `flow-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const job = {
        id: jobId,
        status: "pending",
        createdAt: Date.now(),
        ...message.payload,
      };
      await chrome.storage.local.set({ [`job:${jobId}`]: job, activeFlowJobId: jobId });

      const tabs = await flowTabs();
      let tab = tabs.find((item) => item.url?.includes("/project/")) || tabs[0];
      if (!tab?.id) tab = await chrome.tabs.create({ url: FLOW_HOME, active: false });
      if (tab.id) await notifyFlowAgent(tab.id);
      sendResponse({ ok: true, payload: { jobId } });
      return;
    }

    if (message.type === "CINEGEN_FLOW_JOB_STATUS") {
      const key = `job:${message.payload?.jobId}`;
      const stored = await chrome.storage.local.get(key);
      sendResponse({ ok: true, payload: stored[key] || { status: "missing" } });
      return;
    }

    if (message.type === "CINEGEN_FLOW_JOB_UPDATE") {
      const job = message.payload;
      if (!job?.id) {
        sendResponse({ ok: false, error: "Tarefa Flow inválida." });
        return;
      }
      await api("/jobs/update", {
        method: "POST",
        body: JSON.stringify(job),
      });
      sendResponse({ ok: true, payload: { updated: true } });
      return;
    }

    if (message.type === "CINEGEN_FLOW_FETCH_AS_DATA_URL") {
      const mediaUrl = message.payload?.url;
      if (!mediaUrl || !/^(https?:|blob:|data:)/i.test(mediaUrl)) {
        sendResponse({ ok: false, error: "URL de imagem inválida." });
        return;
      }
      if (mediaUrl.startsWith("data:")) {
        sendResponse({ ok: true, payload: { dataUrl: mediaUrl } });
        return;
      }
      const mediaResponse = await fetch(mediaUrl);
      if (!mediaResponse.ok) {
        throw new Error(`Flow retornou HTTP ${mediaResponse.status} ao baixar a imagem.`);
      }
      const blob = await mediaResponse.blob();
      const bytes = new Uint8Array(await blob.arrayBuffer());
      let binary = "";
      const chunkSize = 0x8000;
      for (let index = 0; index < bytes.length; index += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(index, index + chunkSize));
      }
      sendResponse({
        ok: true,
        payload: {
          dataUrl: `data:${blob.type || "image/png"};base64,${btoa(binary)}`,
        },
      });
      return;
    }

    sendResponse({ ok: false, error: "Comando desconhecido." });
  })().catch((error) => sendResponse({ ok: false, error: error?.message || String(error) }));
  return true;
});
