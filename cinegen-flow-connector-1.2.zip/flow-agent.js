let processing = false;

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function visible(element) {
  if (!element) return false;
  const style = getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  return (
    style.display !== "none" &&
    style.visibility !== "hidden" &&
    rect.width > 0 &&
    rect.height > 0 &&
    rect.bottom > 0 &&
    rect.right > 0 &&
    rect.top < window.innerHeight &&
    rect.left < window.innerWidth
  );
}

function textOf(element) {
  return (element?.innerText || element?.textContent || "").replace(/\s+/g, " ").trim();
}

function findButton(match) {
  return [...document.querySelectorAll("button")].find((button) => (
    visible(button) && match(textOf(button), button.getAttribute("aria-label") || "")
  ));
}

function findRole(role, match) {
  return [...document.querySelectorAll(`[role="${role}"]`)].find((element) => (
    visible(element) && match(textOf(element), element.getAttribute("aria-label") || "")
  ));
}

async function waitFor(find, timeoutMs = 15000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const result = find();
    if (result) return result;
    await wait(300);
  }
  throw new Error("Controle do Google Flow não foi encontrado.");
}

function pageStatus() {
  const profile = findButton((text, label) => (
    /perfil|profile|conta do google|google account|account circle/i.test(`${text} ${label}`)
  ));
  const signIn = findButton((text, label) => (
    /fazer login|sign in|entrar com google|continue with google/i.test(`${text} ${label}`)
  ));
  const insideProject = /\/tools\/flow\/project\//i.test(location.pathname);
  const pageText = textOf(document.body).slice(0, 12_000);
  const creditMatch = pageText.match(/(\d[\d.,]*)\s+(?:cr[eé]ditos?|credits?)(?:\s+do\s+google\s+flow)?/i);
  const plan = /\bULTRA\b/i.test(pageText)
    ? "Ultra"
    : /\bPRO\b/i.test(pageText)
      ? "Pro"
      : creditMatch
        ? `${creditMatch[1]} créditos`
        : profile || insideProject
          ? "Conectado"
          : undefined;
  return {
    signedIn: !signIn && Boolean(profile || insideProject),
    plan,
  };
}

async function updateJob(job, clearActive = false) {
  const values = { [`job:${job.id}`]: job };
  if (clearActive) values.activeFlowJobId = null;
  await chrome.storage.local.set(values);
  try {
    await chrome.runtime.sendMessage({
      type: "CINEGEN_FLOW_JOB_UPDATE",
      payload: job,
    });
  } catch {
    // O estado local será sincronizado novamente quando o CineGen estiver acessível.
  }
}

async function chooseVideoSettings(job) {
  const formatButton = await waitFor(() => findButton((text) => (
    /Nano Banana|Vídeo|Video/.test(text) && /1x/.test(text)
  )));
  formatButton.click();

  const videoTab = await waitFor(() => findRole("tab", (text) => /Vídeo|Video/i.test(text)));
  videoTab.click();
  await wait(300);

  const framesTab = findRole("tab", (text) => /Frames/i.test(text));
  framesTab?.click();

  const ratioTab = await waitFor(() => findRole("tab", (text) => text.includes(job.aspectRatio || "16:9")));
  ratioTab.click();

  const modelButton = await waitFor(() => findButton((text) => /Veo 3\.1/.test(text)));
  modelButton.click();
  const wantedModel = job.model || "Veo 3.1 - Fast";
  const modelOption = await waitFor(() => findButton((text) => text.includes(wantedModel)));
  modelOption.click();
}

async function attachReferenceImage(imageUrl) {
  if (!imageUrl) return;
  const addMedia = findButton((text, label) => /Adicionar mídia|Add media/i.test(`${text} ${label}`));
  if (!addMedia) return;
  addMedia.click();
  const input = await waitFor(() => document.querySelector('input[type="file"]'), 5000).catch(() => null);
  if (!input) return;

  const response = await fetch(imageUrl);
  if (!response.ok) throw new Error("Não foi possível carregar o quadro-base no Flow.");
  const blob = await response.blob();
  const file = new File([blob], "cinegen-reference.png", { type: blob.type || "image/png" });
  const transfer = new DataTransfer();
  transfer.items.add(file);
  input.files = transfer.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  await wait(1200);
}

function promptEditorScore(element) {
  if (!visible(element) || element.closest("nav")) return -1;
  const identity = [
    element.getAttribute("placeholder"),
    element.getAttribute("aria-label"),
    element.getAttribute("data-placeholder"),
  ].filter(Boolean).join(" ");
  if (/buscar|search|pesquisar/i.test(identity)) return -1;
  let score = 0;
  if (/o que voc[eê] quer criar|what do you want to create|descreva|describe|prompt/i.test(identity)) {
    score += 100;
  }
  const rect = element.getBoundingClientRect();
  score += Math.min(30, rect.width / 20);
  score += Math.min(20, rect.height / 5);
  score += Math.min(15, rect.top / 80);
  return score;
}

function findPromptEditor() {
  return [...document.querySelectorAll('[contenteditable="true"], textarea, [role="textbox"]')]
    .map((element) => ({ element, score: promptEditorScore(element) }))
    .filter((item) => item.score >= 0)
    .sort((a, b) => b.score - a.score)[0]?.element;
}

async function enterPrompt(prompt) {
  const editor = await waitFor(findPromptEditor);
  editor.focus();
  if ("value" in editor) {
    const prototype = editor instanceof HTMLTextAreaElement
      ? HTMLTextAreaElement.prototype
      : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (setter) setter.call(editor, prompt);
    else editor.value = prompt;
    editor.dispatchEvent(new Event("input", { bubbles: true }));
    editor.dispatchEvent(new Event("change", { bubbles: true }));
  } else {
    editor.textContent = "";
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(editor);
    selection?.removeAllRanges();
    selection?.addRange(range);
    const inserted = document.execCommand("insertText", false, prompt);
    if (!inserted) editor.textContent = prompt;
    editor.dispatchEvent(new InputEvent("beforeinput", {
      bubbles: true,
      inputType: "insertText",
      data: prompt,
    }));
    editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: prompt }));
  }
  return editor;
}

async function submitPrompt(editor) {
  const containers = [];
  let current = editor;
  for (let depth = 0; depth < 6 && current; depth += 1) {
    containers.push(current);
    current = current.parentElement;
  }
  const submit = await waitFor(() => {
    for (const container of containers) {
      const buttons = [...container.querySelectorAll("button")].filter((button) => (
        visible(button) && !button.disabled
      ));
      const sendButton = buttons.find((button) => {
        const identity = `${textOf(button)} ${button.getAttribute("aria-label") || ""}`;
        return /arrow_forward|enviar|send/i.test(identity);
      });
      if (sendButton) return sendButton;
      const generateButton = buttons.find((button) => {
        const identity = `${textOf(button)} ${button.getAttribute("aria-label") || ""}`;
        return (
          /gerar|generate|criar|create/i.test(identity) &&
          !/add_2|adicionar|add/i.test(identity)
        );
      });
      if (generateButton) return generateButton;
    }
    return null;
  }, 8000);
  submit.click();
}

function currentLargeImageUrls() {
  return new Set(
    [...document.querySelectorAll("img")]
      .filter((image) => image.naturalWidth >= 384 && image.naturalHeight >= 216)
      .map((image) => image.currentSrc || image.src)
      .filter(Boolean),
  );
}

async function waitForImage(previousUrls, approveCredits) {
  const started = Date.now();
  while (Date.now() - started < 18 * 60 * 1000) {
    if (approveCredits) {
      const approve = [...document.querySelectorAll("span, p, div, button, [role='button']")]
        .find((element) => (
          visible(element) &&
          element.children.length === 0 &&
          /^(aprovar|approve)$/i.test(textOf(element))
        ));
      if (approve && !approve.disabled) {
        approve.click();
        await wait(800);
      }
    }
    const candidates = [...document.querySelectorAll("img")]
      .filter((image) => (
        visible(image) &&
        image.naturalWidth >= 512 &&
        image.naturalHeight >= 288
      ))
      .map((image) => ({
        url: image.currentSrc || image.src,
        area: image.naturalWidth * image.naturalHeight,
      }))
      .filter((item) => (
        item.url &&
        !previousUrls.has(item.url) &&
        /^(https?:|blob:|data:)/i.test(item.url)
      ))
      .sort((a, b) => b.area - a.area);
    if (candidates[0]?.url) return candidates[0].url;
    await wait(2000);
  }
  throw new Error("O Flow não retornou a imagem dentro do tempo esperado.");
}

async function portableImageUrl(url) {
  try {
    const localResponse = await fetch(url);
    if (localResponse.ok) {
      const blob = await localResponse.blob();
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(blob);
      });
      if (typeof dataUrl === "string") return dataUrl;
    }
  } catch {
    // URLs protegidas pelo Google são baixadas pelo service worker abaixo.
  }
  const response = await chrome.runtime.sendMessage({
    type: "CINEGEN_FLOW_FETCH_AS_DATA_URL",
    payload: { url },
  });
  if (!response?.ok || !response?.payload?.dataUrl) {
    throw new Error(response?.error || "Não foi possível transferir a imagem do Flow para o CineGen.");
  }
  return response.payload.dataUrl;
}

async function waitForVideo(previousUrls) {
  const started = Date.now();
  while (Date.now() - started < 18 * 60 * 1000) {
    const videos = [...document.querySelectorAll("video")];
    for (const video of videos) {
      const url = video.currentSrc || video.src || video.querySelector("source")?.src;
      if (url && !previousUrls.has(url) && /^(https?:|blob:)/.test(url)) return url;
    }
    await wait(2500);
  }
  throw new Error("O Flow não retornou o vídeo dentro do tempo esperado.");
}

async function processQueue() {
  if (processing) return;
  processing = true;
  try {
    const { activeFlowJobId } = await chrome.storage.local.get("activeFlowJobId");
    if (!activeFlowJobId) return;
    const key = `job:${activeFlowJobId}`;
    const stored = await chrome.storage.local.get(key);
    const job = stored[key];
    if (!job || !["pending", "claimed", "opening_project"].includes(job.status)) return;

    if (!pageStatus().signedIn) {
      await updateJob(
        { ...job, status: "failed", error: "Entre na sua conta Google Flow nesta aba." },
        true,
      );
      return;
    }

    if (!location.pathname.includes("/project/")) {
      const newProject = findButton((text, label) => /Novo projeto|New project/i.test(`${text} ${label}`));
      if (!newProject) throw new Error("Botão Novo projeto não encontrado no Flow.");
      await updateJob({ ...job, status: "opening_project" });
      newProject.click();
      return;
    }

    await updateJob({ ...job, status: "generating" });

    if (job.kind === "image") {
      await attachReferenceImage(job.imageUrl);
      const previousImages = currentLargeImageUrls();
      const editor = await enterPrompt(job.prompt);
      await submitPrompt(editor);
      const generatedImageUrl = await waitForImage(
        previousImages,
        Boolean(job.approveCredits),
      );
      const resultImageUrl = await portableImageUrl(generatedImageUrl);
      await updateJob(
        {
          ...job,
          status: "completed",
          resultImageUrl,
          completedAt: Date.now(),
        },
        true,
      );
      return;
    }

    const previousUrls = new Set(
      [...document.querySelectorAll("video")]
        .map((video) => video.currentSrc || video.src)
        .filter(Boolean)
    );
    await attachReferenceImage(job.imageUrl);
    await chooseVideoSettings(job);
    const editor = await enterPrompt(job.prompt);
    await submitPrompt(editor);

    const videoUrl = await waitForVideo(previousUrls);
    await updateJob(
      { ...job, status: "completed", videoUrl, completedAt: Date.now() },
      true,
    );
  } catch (error) {
    const { activeFlowJobId } = await chrome.storage.local.get("activeFlowJobId");
    if (activeFlowJobId) {
      const key = `job:${activeFlowJobId}`;
      const stored = await chrome.storage.local.get(key);
      await updateJob(
        {
          ...(stored[key] || { id: activeFlowJobId }),
          status: "failed",
          error: error?.message || String(error),
        },
        true,
      );
    }
  } finally {
    processing = false;
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "CINEGEN_FLOW_PAGE_STATUS") {
    sendResponse(pageStatus());
    return;
  }
  if (message.type === "CINEGEN_FLOW_PROCESS_QUEUE") {
    processQueue();
    sendResponse({ accepted: true });
  }
});

window.addEventListener("load", () => setTimeout(processQueue, 1200));
setTimeout(processQueue, 1500);
