let processing = false;

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function visible(element) {
  if (!element) return false;
  const style = getComputedStyle(element);
  const rect = element.getBoundingClientRect();
  return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;
}

function textOf(element) {
  return (element?.innerText || element?.textContent || "").replace(/\s+/g, " ").trim();
}

function findButton(match) {
  return [...document.querySelectorAll("button")].find((button) => (
    visible(button) && match(textOf(button), button.getAttribute("aria-label") || "")
  ));
}

function findRole(role, match) {
  return [...document.querySelectorAll(`[role="${role}"]`)].find((element) => (
    visible(element) && match(textOf(element), element.getAttribute("aria-label") || "")
  ));
}

async function waitFor(find, timeoutMs = 15000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const result = find();
    if (result) return result;
    await wait(300);
  }
  throw new Error("Controle do Google Flow não foi encontrado.");
}

function pageStatus() {
  const profile = findButton((text, label) => /perfil do usu[aá]rio|user profile/i.test(`${text} ${label}`));
  const plan = /PRO/i.test(textOf(profile)) ? "PRO" : profile ? "Conectado" : undefined;
  return { signedIn: Boolean(profile), plan };
}

async function updateJob(job, clearActive = false) {
  const values = { [`job:${job.id}`]: job };
  if (clearActive) values.activeFlowJobId = null;
  await chrome.storage.local.set(values);
  try {
    await chrome.runtime.sendMessage({
      type: "CINEGEN_FLOW_JOB_UPDATE",
      payload: job,
    });
  } catch {
    // O estado local será sincronizado novamente quando o CineGen estiver acessível.
  }
}

async function chooseVideoSettings(job) {
  const formatButton = await waitFor(() => findButton((text) => (
    /Nano Banana|Vídeo|Video/.test(text) && /1x/.test(text)
  )));
  formatButton.click();

  const videoTab = await waitFor(() => findRole("tab", (text) => /Vídeo|Video/i.test(text)));
  videoTab.click();
  await wait(300);

  const framesTab = findRole("tab", (text) => /Frames/i.test(text));
  framesTab?.click();

  const ratioTab = await waitFor(() => findRole("tab", (text) => text.includes(job.aspectRatio || "16:9")));
  ratioTab.click();

  const modelButton = await waitFor(() => findButton((text) => /Veo 3\.1/.test(text)));
  modelButton.click();
  const wantedModel = job.model || "Veo 3.1 - Fast";
  const modelOption = await waitFor(() => findButton((text) => text.includes(wantedModel)));
  modelOption.click();
}

async function attachReferenceImage(imageUrl) {
  if (!imageUrl) return;
  const addMedia = findButton((text, label) => /Adicionar mídia|Add media/i.test(`${text} ${label}`));
  if (!addMedia) return;
  addMedia.click();
  const input = await waitFor(() => document.querySelector('input[type="file"]'), 5000).catch(() => null);
  if (!input) return;

  const response = await fetch(imageUrl);
  if (!response.ok) throw new Error("Não foi possível carregar o quadro-base no Flow.");
  const blob = await response.blob();
  const file = new File([blob], "cinegen-reference.png", { type: blob.type || "image/png" });
  const transfer = new DataTransfer();
  transfer.items.add(file);
  input.files = transfer.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  await wait(1200);
}

async function enterPrompt(prompt) {
  const editor = await waitFor(() => (
    [...document.querySelectorAll('[contenteditable="true"], textarea, [role="textbox"]')]
      .find((element) => visible(element) && !element.closest("nav"))
  ));
  editor.focus();
  if ("value" in editor) {
    editor.value = prompt;
    editor.dispatchEvent(new Event("input", { bubbles: true }));
  } else {
    editor.textContent = prompt;
    editor.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: prompt }));
  }
}

async function waitForVideo(previousUrls) {
  const started = Date.now();
  while (Date.now() - started < 18 * 60 * 1000) {
    const videos = [...document.querySelectorAll("video")];
    for (const video of videos) {
      const url = video.currentSrc || video.src || video.querySelector("source")?.src;
      if (url && !previousUrls.has(url) && /^(https?:|blob:)/.test(url)) return url;
    }
    await wait(2500);
  }
  throw new Error("O Flow não retornou o vídeo dentro do tempo esperado.");
}

async function processQueue() {
  if (processing) return;
  processing = true;
  try {
    const { activeFlowJobId } = await chrome.storage.local.get("activeFlowJobId");
    if (!activeFlowJobId) return;
    const key = `job:${activeFlowJobId}`;
    const stored = await chrome.storage.local.get(key);
    const job = stored[key];
    if (!job || !["pending", "opening_project"].includes(job.status)) return;

    if (!pageStatus().signedIn) {
      await updateJob(
        { ...job, status: "failed", error: "Entre na sua conta Google Flow nesta aba." },
        true,
      );
      return;
    }

    if (!location.pathname.includes("/project/")) {
      const newProject = findButton((text, label) => /Novo projeto|New project/i.test(`${text} ${label}`));
      if (!newProject) throw new Error("Botão Novo projeto não encontrado no Flow.");
      await updateJob({ ...job, status: "opening_project" });
      newProject.click();
      return;
    }

    await updateJob({ ...job, status: "generating" });
    const previousUrls = new Set(
      [...document.querySelectorAll("video")]
        .map((video) => video.currentSrc || video.src)
        .filter(Boolean)
    );
    await attachReferenceImage(job.imageUrl);
    await chooseVideoSettings(job);
    await enterPrompt(job.prompt);

    const createButton = await waitFor(() => (
      [...document.querySelectorAll("button")].find((button) => {
        const identity = `${textOf(button)} ${button.getAttribute("aria-label") || ""}`;
        return visible(button) &&
          !button.disabled &&
          /Criar|Create/i.test(identity) &&
          /arrow_forward|Gerar|Generate/i.test(identity);
      })
    ));
    if (createButton.disabled) throw new Error("O botão Criar do Flow permaneceu desativado.");
    createButton.click();

    const videoUrl = await waitForVideo(previousUrls);
    await updateJob(
      { ...job, status: "completed", videoUrl, completedAt: Date.now() },
      true,
    );
  } catch (error) {
    const { activeFlowJobId } = await chrome.storage.local.get("activeFlowJobId");
    if (activeFlowJobId) {
      const key = `job:${activeFlowJobId}`;
      const stored = await chrome.storage.local.get(key);
      await updateJob(
        {
          ...(stored[key] || { id: activeFlowJobId }),
          status: "failed",
          error: error?.message || String(error),
        },
        true,
      );
    }
  } finally {
    processing = false;
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "CINEGEN_FLOW_PAGE_STATUS") {
    sendResponse(pageStatus());
    return;
  }
  if (message.type === "CINEGEN_FLOW_PROCESS_QUEUE") {
    processQueue();
    sendResponse({ accepted: true });
  }
});

window.addEventListener("load", () => setTimeout(processQueue, 1200));
setTimeout(processQueue, 1500);
